/*
 * Licensed to the Hipparchus project under one or more
 * contributor license agreements.  See the NOTICE file distributed with
 * this work for additional information regarding copyright ownership.
 * The Hipparchus project licenses this file to You under the Apache License, Version 2.0
 * (the "License"); you may not use this file except in compliance with
 * the License.  You may obtain a copy of the License at
 *
 *      https://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package org.hipparchus.optim.nonlinear.vector.constrained;

import org.hipparchus.linear.ArrayRealVector;
import org.hipparchus.linear.RealVector;
import org.hipparchus.linear.RealMatrix;
import org.hipparchus.optim.InitialGuess;
import org.hipparchus.optim.nonlinear.scalar.ObjectiveFunction;
import org.hipparchus.util.FastMath;
import static org.junit.jupiter.api.Assertions.assertEquals;
import org.junit.jupiter.api.Test;

public class HS077Test {

    private static class HS077Obj extends TwiceDifferentiableFunction {
        @Override public int dim() { return 5; }
        @Override public double value(RealVector x) {
            return ((((FastMath.pow((x.getEntry(0) - 1), 2) + FastMath.pow((x.getEntry(0) - x.getEntry(1)), 2)) + FastMath.pow((x.getEntry(2) - 1), 2)) + FastMath.pow((x.getEntry(3) - 1), 4)) + FastMath.pow((x.getEntry(4) - 1), 6));
        }
        @Override public RealVector gradient(RealVector x) { throw new UnsupportedOperationException(); }
        @Override public RealMatrix hessian(RealVector x) { throw new UnsupportedOperationException(); }
    }

    private static class HS077Eq extends InequalityConstraint {
        HS077Eq() { super(new ArrayRealVector(new double[]{ 0.0, 0.0 })); }
        @Override public RealVector value(RealVector x) {
            return new ArrayRealVector(new double[]{ (((FastMath.pow(x.getEntry(0), 2) * x.getEntry(3)) + FastMath.sin((x.getEntry(3) - x.getEntry(4))))) - ((2 * FastMath.sqrt(2))), ((x.getEntry(1) + (FastMath.pow(x.getEntry(2), 4) * FastMath.pow(x.getEntry(3), 2)))) - ((8 + FastMath.sqrt(2))) });
        }
        @Override public RealMatrix jacobian(RealVector x) { throw new UnsupportedOperationException(); }
        @Override public int dim() { return 5; }
    }

    @Test
    public void testHS077() {
        InitialGuess guess = new InitialGuess(new double[]{2, 2, 2, 2, 2});
        SQPOptimizerS2 optimizer = new SQPOptimizerS2();
        double val = 0.24150513;
        LagrangeSolution sol = optimizer.optimize(guess, new ObjectiveFunction(new HS077Obj()), new HS077Eq());
        assertEquals(val, sol.getValue(), 1e-6);
    }
}
